package com.serloc.springboot.demo.holamon;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HolamonApplication {

	public static void main(String[] args) {
		SpringApplication.run(HolamonApplication.class, args);
	}

}
