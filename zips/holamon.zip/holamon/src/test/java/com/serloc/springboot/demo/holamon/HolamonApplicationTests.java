package com.serloc.springboot.demo.holamon;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HolamonApplicationTests {

	@Test
	void contextLoads() {
	}

}
